# bikinematicsolver

to use:

go look at the test_bike.py thats pretty much all it does
